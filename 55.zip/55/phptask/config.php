<?php 
//error_reporting(0);

$dbhost='localhost';
$dbname= 'taskform';
$dbusername='root'; 
$dbpass='';


$mysqli=mysqli_connect($dbhost,$dbusername,$dbpass,$dbname);
if($mysqli === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

 ?>
