-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2021 at 11:45 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taskform`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'aman@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `formcr`
--

CREATE TABLE `formcr` (
  `sno` int(10) NOT NULL,
  `firstname` char(20) NOT NULL,
  `lastname` char(20) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `image` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `formcr`
--

INSERT INTO `formcr` (`sno`, `firstname`, `lastname`, `gender`, `phone`, `email`, `qualification`, `image`, `password`, `posting_date`) VALUES
(407, 'vidhi', 'sharma', 'female', '8577485596', 'sharma@gmail.com', '12th', 'Sarita-Vijay.jpg', '', '2021-11-08 05:48:08'),
(408, 'naveen', 'kumar', 'male', '7488596687', 'nv@gmial.com', 'Graduation', 'santosh-kumar.png', '', '2021-11-08 05:48:08'),
(411, 'Firoj', 'khan', 'male', '4775866968', 'firoj@gmail.com', '12', 'sof-santosh-anand.png', '', '2021-11-08 05:48:08'),
(412, 'vijay', 'shafma', 'Female', '1234567890', 'sharma85@gmail.com', 'Post graduation', 'santosh-kumar.png', '123456', '2021-11-08 05:48:08'),
(413, 'nikita', 'jain', 'male', '9688748596', 'nikita45@gmail.com', 'Graduation', 'shu.jpg', 'nikita123', '2021-11-08 05:48:08'),
(414, 'paras', 'jain', 'male', '9600748596', 'nikita15@gmail.com', '10', '20160420051756-433px-Santosh-Panda-Profile-Picture2.jpeg', 'nikita123', '2021-11-08 05:48:08'),
(415, 'swati', 'verma', 'male', '7488596850', 'swati@gmail.com', 'Post graduation', 'images (2).jpg', 'sw123', '2021-11-08 05:48:08'),
(416, 'kritika', 'malav', 'Female', '7488596620', 'kr@gmail.com', 'Post graduation', 'Sarita-Vijay.jpg', 'kr123', '2021-11-08 05:48:08'),
(419, 'neeraj', 'malv', 'male', '4788596636', 'n@gmail.com', 'Graduation', 'santosh-kumar.png', 'n123', '2021-11-08 05:48:08'),
(420, 'viky', 'sharma', 'male', '7855967740', 'vijay@gail.com', 'Post graduation', '20160420051756-433px-Santosh-Panda-Profile-Picture2.jpeg', '123456', '2021-11-08 05:51:34'),
(421, 'vijay', 'kumar', 'male', '4758869633', 'vij@gmail.com', '12', 'images.jpg', '123456', '2021-11-08 06:16:27'),
(422, 'vijay', 'kumar', 'Female', '8599697488', 'vh5@gmail.com', 'Graduation', 'sh.jpg', '123456', '2021-11-08 06:17:38'),
(423, 'nakul', 'jain', 'male', '7588696332', 'nakul@gmail.com', 'Post graduation', 'santosh-kumar.png', '1235', '2021-11-08 06:30:56'),
(424, 'arun', 'kumar', 'male', '7483325601', 'arun@gmal.com', 'Graduation', 'download.jpg', 'arun123', '2021-11-08 06:33:56'),
(425, 'anuradha', 'kumari', 'Female', '7488025601', 'arun5@gmal.com', 'Graduation', 'shu.jpg', 'arun123', '2021-11-08 06:34:54'),
(426, 'arjun', 'thapa', 'male', '8699587485', 'ar@gmail.com', '12', 'images.jpg', '123', '2021-11-08 06:36:58'),
(427, 'jiyoti', 'verma', 'Female', '9688574850', 'ji@gmail.com', 'Post graduation', 'Sarita-Vijay.jpg', '123', '2021-11-08 07:54:27'),
(428, 'kavita', 'sharma', 'Female', '8599674859', 'kv@gmail.com', 'Graduation', 'sh.jpg', '123', '2021-11-08 07:56:09'),
(429, 'vishu', 'thapa', 'male', '7488596256', 'vishu@gmail.com', 'Post graduation', '20160420051756-433px-Santosh-Panda-Profile-Picture2.jpeg', '123', '2021-11-08 08:07:38'),
(430, 'avi', 'thapa', 'male', '7488596024', 'avi@gmail.com', 'Post graduation', 'images (2).jpg', '789', '2021-11-08 08:09:15'),
(431, 'nikil', 'verma', 'male', '1255859645', 'nj@gmail.com', '12', 'images.jpg', 'nj123', '2021-11-08 10:29:10'),
(432, 'navaid', 'khan', 'male', '5288596980', 'nav@gmail.com', '12', 'sof-santosh-anand.png', 'nav123', '2021-11-08 10:55:26'),
(433, 'sachin', 'sharma', 'male', '7855969857', 'sachin@gmail.com', 'Post graduation', 'download.jpg', 'sachin', '2021-11-08 10:57:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formcr`
--
ALTER TABLE `formcr`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `formcr`
--
ALTER TABLE `formcr`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=434;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
