

<?php
include("config.php");
?>


<?php 
          $id = $_GET['id'];
          if (isset($_GET['id'])) {
			// echo  print_r($id);die();
           // echo  print_r($id);die();
          $sql= mysqli_query($mysqli, "DELETE FROM `formcr` WHERE sno =$id");
           echo "YOUR DETAIL WAS SUCESSFULL  DELETE !"; 
           // header('location: index.php');

          }
          ?>



<?php  
$mysqli->close(); 

?>


