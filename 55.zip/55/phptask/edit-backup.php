<?php
include("config.php");
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>
<body>
    <h1 style="align-content: center; font-size: 25px; font-family: Lato; font-weight: bold;"> Update Form</h1>
<?php 
  if (isset($_GET['id'])) 
  {
    $id = $_GET['id'];
    //$update = true;
    $qry = mysqli_query($mysqli,"select * from formcr where sno='$id'"); // select query
    //echo  print_r($qry);die();
    $data = mysqli_fetch_array($qry); // fetch data
     
    $firstname = $data['firstname'];
    $lastname = $data['lastname'];
    $gender = $data['gender'];
    $phone = $data['phone'];
    $email = $data['email'];
    $qualification = $data['qualification'];
    $filename= $data['image'];
  };
?>


  <form action="" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="id" value="<?php echo $id; ?>">

      <div class="mb-3">
              <label for="first name" class="form-label"><strong>First name</strong></label>
              <input type="text" class="form-control"  id="fname" aria-describedby="fname" name="firstname" value="<?php echo $data['firstname'] ?>">
              
                  
              
              

            </div>
  
            <div class="mb-3">
              <label for="last name" class="form-label"><strong>Last Name</strong></label>
              <input type="text" class="form-control"  id="lname" aria-describedby="fname" name="lastname" value="<?php echo $data['lastname'] ?>" >
              
              
            </div>

            <div class="mb-3 form-check">          
              
              <label for=""><strong>Gender</strong></label> <br>
                <!-- <input type="radio" name="gender"  id="gender" required /> Male <br>
                <input type="radio" name="gender"  id="gender" required /> Female -->
           
              <input type="radio" name="gender" value="male" <?php if($data['gender']=="male"){ echo "checked";}?>/>Male <br>
              <input type="radio" name="gender" value="female" <?php if($data['gender']=="female"){ echo "checked";}?>/>Female
               </div>


            <div class="mb-3">
              <label for="" class="form-label"> <strong>Contact No.</strong> </label>
              <input type="number" class="form-control"  id="contact" aria-describedby="contact" name="phone" value="<?php echo $data['phone'] ?>">
              
              

            </div>
          
          
            <div class="mb-3">
              <label for="email" class="form-label"><strong>Email</strong></label>
              <input type="email" class="form-control"  id="email" aria-describedby="fname" name="email" 
              value="<?php echo $data['email'] ?>" />
              
                          
              
            </div>
          
          

  
            <div class="mb-3">

  <select name="qualification" id="qualification" value="<?php echo $data['qualification'] ?>" style="display: inline-block; border: 1px solid #5585c1; background-color: #4414; padding: 15px 32px; text-align: center; text-decoration: none; cursor: pointer; ">
  <option selected ><strong>Choose Your Qualification</strong></option>
  <option value="10th"<?php if($data["qualification"]=='10'){echo "selected";}?>>10th</option>
  <option value="12th"<?php if($data["qualification"]=='12'){echo "selected";}?>>12th</option>
  <option value="Graduation"<?php if($data["qualification"]=='Graduation'){echo "selected";}?>>graduation</option>
  <option value="post graduation"<?php if($data["qualification"]=='Post graduation'){echo "selected";}?>>post graduation </option>
  </select>

             

            </div>


            <div>
              <strong>Your Picture</strong>
            <input type="file" name="image"  id="image"  value="<?php echo $filename; ?>"  /><img src="img/<?php echo $filename;?>" width="200px" height="200px"/>
            
            </div>

             
              

            <br>
      
      
    <?php //if ($update == true): ?>
      <button class="btn" type="submit" name="update" style="background: blueviolet;">Update</button>
    <?php //endif; ?>
      
       
</form>
        <?php  
      if (isset($_POST['update'])) 
  {

      $id = $_POST['id'];
      $firstname = $_POST['firstname'];
      $lastname = $_POST['lastname'];
      $gender = $_POST['gender'];
      $phone = $_POST['phone'];
      $email = $_POST['email'];
      $qualification = $_POST['qualification'];
      $filename = $_FILES['image'];
      

      $filename = $_FILES['image']['name'];
        // Select file type
      $imageFileType = strtolower(pathinfo($filename,PATHINFO_EXTENSION));
        // valid file extensions
      $extensions_arr = array("jpg","jpeg","png","gif");

       
      if(move_uploaded_file($_FILES["image"]["tmp_name"],'img/'.$filename))
    {

      
      if(!empty($firstname) && !empty($lastname) && !empty($gender) && !empty($phone) &&  !empty($email) && !empty
        ($qualification) && in_array($imageFileType,$extensions_arr)):

      
      
      // echo  print_r($filename);die();
      $updt= mysqli_query($mysqli, "UPDATE `formcr` SET firstname='$firstname', lastname='$lastname', gender='$gender', phone ='$phone', email='$email', qualification='$qualification', image='$filename' WHERE sno='$id'");
      //echo print_r($updt);die();
          echo "Detail Updated sucessfull Good Job !"; 
          
          endif;
    }
        
        // echo  print_r($updt);die();

}

    //echo "$updt";die()
        ?>
</body>
</html>





