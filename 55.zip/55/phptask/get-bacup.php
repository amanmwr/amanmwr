<?php session_start(); 
include("config.php");
if (strlen($_SESSION['sno']==0)) {
  header('location:logout.php');
  } else{
?>



<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title> Fatch Data</title>

  <style type="text/css">
    table {
      font-family: arial, sans-serif;
      border-collapse: collapse;
      width:100%;
    }

    td, th {
      border: 2px solid #000000;
      text-align: center;
      padding: 5px;
      margin: 0px;
    }

    tr:nth-child(even) {
      background-color: #dddddd; 


</style>
</head>
<body>
       <a href="logout.php" style="border: 1px solid #1142cc; background-color: #000000; color: white;  padding: 15px 32px;text-align: center;text-decoration: none; display: block; font-size: 16px;margin: 4px 2px; cursor: pointer;">Logout</a>

  <table>
            <tr>
                <th>ID</th>
                <th>FIRST NAME</th>
                <th>LAST NAME</th>
                <th>GENDER</th>
                <th>MOBILE No.</th>
                <th>EMAIL</th>
                <th>QUALIFICATION</th>
                <th>IMAGE</th>
                <th>Reg.Date+Time</th>
                <th>ACTION EDIT</th>
                <th>ACTION DELETE</th>
                


            </tr>

  
     
    <?php
    $email=$_SESSION['email']; 
    $sql = mysqli_query($mysqli, "SELECT * FROM `formcr` where email='$email' ");
      While($data=mysqli_fetch_array($sql))

  {
  ?>
  
    <tr>
      <td><?php echo $data['sno'];?></td>
      <td><?php echo $data['firstname'];?></td>
      <td><?php echo $data['lastname'];?></td>
      <td><?php echo $data['gender'];?></td>
      <td><?php echo $data['phone'];?></td>
      <td><?php echo $data['email'];?></td>
      <td><?php echo $data['qualification'];?></td>   
      <td><img src="<?php echo 'img/'.$data['image'];?>" width="100" height="100" /></td>
      <td><?php echo $data['posting_date'];?></td>


      
      <td>
        
        <a href="edit.php?id=<?php echo $data['sno']; ?>" style="border: 1px solid #1142cc; background-color: #0D6EFD; color: white;  padding: 15px 32px;text-align: center;text-decoration: none; display: block; font-size: 16px;margin: 4px 2px; cursor: pointer;">Edit</a>

      </td>

      <td><a href="delete.php?id=<?php echo $data["sno"]; ?>" style="border: 1px solid darkred; background-color: darkred; color: white;  padding: 15px 32px;text-align: center;text-decoration: none; display: block; font-size: 16px;margin: 4px 2px; cursor: pointer;">Delete</a></td>



    </tr>

    <?php

    } 
    ?>


</table>
</body>
</html>

<?php } ?>
  