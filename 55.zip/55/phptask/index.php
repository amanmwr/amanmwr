  <?php session_start();
include("config.php");
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Crud  Task </title>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  
  <!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>


<script type="text/javascript">
          function checkpass()
          {
          if(document.signup.password.value!=document.signup.conformpassword.value)
          {
          alert(' Password and Confirm Password field does not match');
          document.signup.conformpassword.focus();
          return false;
          }
          return true;
          } 

          </script>
  <!---<style type="text/css">
  table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    border-width: 4px;
    width: 100%;

  }

  td, th {
    border: 1px solid #dddddd;
    text-align: right;
    padding: 8px;
  }

  tr:nth-child(even) {
    background-color: #dddddd;



</style>-->
</head>
<body>


<h1 style="align-content: center; font-size: 25px; font-family: Lato; font-weight: bold;"> Registration Form</h1>
<?php 


  if (isset($_POST['submit']))
    
{

    if(!empty($_POST['firstname']))
    {
      $firstname = $_POST['firstname'];
      $msg_first_name=null;
    }
    else{

      $firstname = null;
      $msg_first_name = "You must supply your First name";
    }



    if(!empty($_POST['lastname']))
    {
      $lastname = $_POST['lastname'];
      $msg_last_name=null;
    }
    else{

      $lastname = null;
      $msg_last_name = "You must supply your Last name";
    }


    if(!empty($_POST['gender']))
    {
      $gender = $_POST['gender'];
      $msg_gender_name = null;
    }
    else{

      $gender = null;
      $msg_gender_name = "Choose Your Gender ";

    }

    
    if(!empty($_POST['phone']))
    {
      $phone = $_POST['phone'];
      $msg_phone_name = null;
    }
    else{
      $phone = null;
      $msg_phone_name = "Enter Your Correct Phone No.";
    }


    if(!empty($_POST['email']))
    {
      $email = $_POST['email'];
      $msg_email_name=null;
    }
    else {
        $email = null;
        $msg_Email_name = "Enter Your Email Now  ";
    }

///

    if(!empty($_POST['qualification']))
    {
      $qualification = $_POST['qualification'];
      $msg_qualification_name = null;
    }
    else{

      $qualification = null;
      $msg_qualification_name = "Choose Your qualification";
    }

///    

    if(!empty($_FILES['image']))
      {
        $filename = $_FILES['image'];
        $msg_image_name=null;
      }
      else
      {
        $filename = null;
        $msg_image_name = "Choose Image From Your PC";
      }



     

      $filename = $_FILES['image']['name'];
        // Select file type
      $imageFileType = strtolower(pathinfo($filename,PATHINFO_EXTENSION));
        // valid file extensions
      $extensions_arr = array("jpg","jpeg","png","gif");
   
///

    if(!empty($_POST['password']))
    {
      $password = $_POST['password'];
      $msg_password_name=null;
    }
    else {
        $password = null;
        $msg_password_name = "Enter Your password  ";
    }
///
    //  if(!empty($_POST['conformpassword']))
    // {
    //   
    //   $msg_conformpassword_name=null;
    // }
    // else {
    //     $conformpassword = null;
    //     $msg_conformpassword_name = "Enter Your Conform password  ";
    // }
  
         


          




    $sql="select * from formcr where (phone ='$phone' or email='$email');";

      $res=mysqli_query($mysqli,$sql);

      if (mysqli_num_rows($res) > 0) 
    {
        
        $row = mysqli_fetch_assoc($res);
        if($email ==isset($row['email']))
        {
              echo " email already exists <br>";
        }
          if($phone ==isset($row['phone']))
          {
                    echo "Contact no already exists<br>";
          }


    }

  else
  { 

            $insert =  "INSERT INTO `formcr` (`phone`, `email`)";
            $sql = ("SELECT 'phone','email'
            WHERE NOT EXISTS (Select `phone` , `email`  From `formcr` WHERE `email`)") ;
              
      
      
    if(move_uploaded_file($_FILES["image"]["tmp_name"],'img/'.$filename))
    {

      
      if(!empty($firstname) && !empty($lastname) && !empty($gender) && !empty($phone) &&  !empty($email) && !empty
        ($qualification) && in_array($imageFileType,$extensions_arr) && !empty($password)):
            
            if ($_POST["password"] === $_POST["conformpassword"]) {
               // success!
            }
            else {
               // failed :(
            }


     $insert = "INSERT INTO `formcr`(`firstname`, `lastname`, `gender`, `phone`, `email`, `qualification`, `image`, `password`) VALUES ('$firstname','$lastname','$gender','$phone','$email' 
       , '$qualification','$filename' , '$password')";



          
            $run = mysqli_query($mysqli,$insert) ;
                  
        
          echo " Success Good Job <br>";
        
          else:
        
          echo " Data Not Inserted <br> ";
        

          endif;
    }
  }
}
  ?>
<form action="" method="POST" enctype="multipart/form-data"  name="signup" 
onsubmit="return checkpass();">
            <div class="mb-3">
              <label for="first name" class="form-label">First Name</label>
              <input type="text" class="form-control"  id="fname" aria-describedby="fname" name="firstname" value='<?php if(!empty($firstname)) echo  $firstname; ?>'>
              
                  
              
              <?php 
              if(!empty($msg_first_name)):
                  echo "<h2 class='alert alert-danger' role='alert'>". $msg_first_name .'</h2>';
              endif; 
              ?>

            </div>
  
            <div class="mb-3">
              <label for="last name" class="form-label">Last Name</label>
              <input type="text" class="form-control"  id="lname" aria-describedby="fname" name="lastname" value='<?php if(!empty($lastname)) echo  $lastname; ?>' >
              
              <?php if(!empty($msg_last_name)):
              {
              echo "<h2 class='lert alert-danger' role= 'alert'>". $msg_last_name .'</h2>';
              }
              endif;
            
              ?>
            </div>

            <div class="mb-3 form-check">
                          
              <label for="">Gender</label> <br>
                <input type="radio" name="gender"  id="gender"  value="male"<?php if ((!isset($_POST['Male'])) || ((isset
                  ($_POST['Male'])) == 1)) {echo 'checked="checked"';}; ?> /> Male <br>
                <input type="radio" name="gender"  id="gender"  value="Female"<?php if ((!isset($_POST['Female'])) || ((isset
                  ($_POST['Female'])) == 0)) {echo 'checked="checked"';}; ?> /> Female 
              
                <?php 
              if(!empty($msg_gender_name)):
                  echo "<h2 class='alert alert-danger' role='alert'>". $msg_gender_name .'</h2>';
              endif; 
              ?>

              
                

            </div>

            <div class="mb-3">
              <label for="" class="form-label">Contact No. </label>
              <input type="number" class="form-control"  id="contact" aria-describedby="contact" name="phone" value='<?php if(!empty($phone)) echo  $phone; ?>'>
              
              <?php 
              if(!empty($msg_phone_name)):
                  echo "<h2 class='alert alert-danger' role='alert'>". $msg_phone_name .'</h2>';
              endif; 
              ?>

            </div>
          
          
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input type="email" class="form-control"  id="email" aria-describedby="fname" name="email" 
              value='<?php if(!empty($email)) echo  $email; ?>' >
              
              <?php 
              if(!empty($msg_Email_name)):
                  echo "<h2 class='alert alert-danger' role='alert'>". $msg_Email_name .'</h2>';
              endif; 
              ?>            
              
            </div>
          
            <div class="mb-3">

            <select name="qualification" id="qualification" style="display: inline-block; border: 1px solid #5585c1; background-color: #4414; padding: 15px 32px; text-align: center; text-decoration: none; cursor: pointer;  ">
            <option selected >Choose Your Qualification</option>
            <option value="10"<?php if(!empty($qualification) && ($qualification == "10")) echo "SELECTED";?>>10th</option>
            <option value="12"<?php if(!empty($qualification) && ($qualification == "12")) echo "SELECTED";?>>12th</option>
            <option value="Graduation" <?php if(!empty($qualification) && ($qualification == "Graduation")) echo "SELECTED";?>>Graduation</option>
            <option value="Post graduation" <?php if(!empty($qualification) && ($qualification == "Post graduation")) echo "SELECTED";?>>Post Graduation</option>
            </select>

            <?php 
              if(!empty($msg_qualification_name)):
                  echo "<h2 class='alert alert-danger' role='alert'>". $msg_qualification_name .'</h2>';
              endif; 
              ?>  

            </div>


            <div class="mb-3">
            <input type="file" name="image"  id="image"  value="" />
            
            </div>


            <div class="mb-3">

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" value='<?php if(!empty($password)) echo  $password; ?>' >

             
            <?php 
            if(!empty($msg_password_name)):
                echo "<h2 class='alert alert-danger' role='alert'>". $msg_password_name .'</h2>';
            endif; 
            ?>

            <label for="conformpassword">Conform Password:</label>
            <input type="password" id="conformpassword" name="conformpassword" value='<?php if(!empty($conformpassword)) echo  $conformpassword; ?>' >

            <?php 
            if(!empty($msg_conformpassword_name)):
                echo "<h2 class='alert alert-danger' role='alert'>". $msg_conformpassword_name .'</h2>';
            endif; 
            ?>
            
          </div>

             
            

            <br>
      
      
    
        <button type="submit" class="btn btn-primary" name="submit" style="display: block; " >Submit</button>
        <a href="./get.php" style="border: 1px solid #1142cc; background-color: #0D6EFD; color: white;  padding: 15px 32px;text-align: center;text-decoration: none; display: block; font-size: 16px;margin: 4px 2px; cursor: pointer; " >View Data</a>

</form>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="js/scripts.js"></script>
</body>
</html>


