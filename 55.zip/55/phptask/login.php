<?php session_start(); 
include("config.php");
if (strlen($_SESSION['sno']==1)) {
  header('location:logout.php');
  } else{




if(isset($_POST['login']))
{
  $email=$_POST['email'];
  $password=($_POST['password']);
  //echo $email; echo $password;die();
$ret=mysqli_query($mysqli,"SELECT * FROM `formcr` WHERE email='$email' and password='$password'");
$num=mysqli_fetch_array($ret);
if($num>0)
{

$extra="get.php";
$_SESSION['email']=$_POST['email'];
$_SESSION['sno']=$num['sno'];
echo "<script>window.location.href='".$extra."'</script>";
exit();
}
else
{
echo "<script>alert('Invalid username or password');</script>";
    $extra="login.php";
echo "<script>window.location.href='".$extra."'</script>";
exit();
}
}
?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login </title>
	<link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <script src="https://use.fontawesome.com/a0875184bf.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
</head>
<body> 

	 <div class="main">
    <p class="sign" align="center">Sign In Spanco Web </p>
    <form class="form1" method="POST" action="" name="login-form" >
      <input class="un " type="email" align="center" name="email" placeholder="Email">
      <input class="pass" type="password" align="center" name="password" placeholder="Password">
      <button class="submit" name="login"type="submit">Login</button>
      <!-- <a href="get.php" class="submit" name="login" align="center" type="submit">Sign in</a> -->
      <!-- <p class="forgot" align="center"><a href="#">Forgot Password?</p> -->     
              
    </div>
</form>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="../js/scripts.js"></script>
</body>
</html>

<?php } ?>